<?PHP
    system("./PPero");
    system("./svm_learn -z c train.txt model.txt");
    system("./predict");
    system("./svm_classify predict.txt model.txt result.txt");
    unlink("model.txt");
    unlink("train.txt");
    unlink("predict.txt");
    unlink("matrix.txt");
?>
    
    
    
    

