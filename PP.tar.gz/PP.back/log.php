<?php
$Uemail= $_POST["Puser"].PHP_EOL;
$Uname= $_POST["Pname"].PHP_EOL;
$Ucomment= $_POST["Pcontent"].PHP_EOL;
$Utime=date('d-m-Y  H:i:s').PHP_EOL;

$filename = 'log.txt';
if (is_writable($filename)) {

    if (!$fp = fopen($filename, 'a')) {
         echo "file to open $filename";
         exit;
    }

    if (fwrite($fp, $Utime) === FALSE) {
        echo "file to write $filename";
        exit;
    }

    fwrite($fp, $Uemail);


    fwrite($fp, $Uname);



    fwrite($fp, $Ucomment);



    fclose($fp);
} else {
    echo " $filename can not be written";
}


header('location: '.$_SERVER['HTTP_REFERER']);

?>




