<?php
    $myfile = fopen("candidates.fasta", "r") or die("Unable to open file!");
    $file = fopen("result.txt", "r") or die("Unable to open file!");
    $newfile = fopen("newresults.txt", "w") or die("Unable to open file!");
    $buffer=fgets($myfile);
    if ($buffer[0]=='>'){
        
        $buffer=$buffer.",".fgets($file);
        $buffer=str_replace("\n","",$buffer);
        fwrite($newfile, $buffer.",");
    }

    while(!feof($myfile)) {
        $buffer=fgets($myfile);
        if ($buffer[0]=='>'){
            fseek($myfile,-15,SEEK_CUR);
            $buffer2="";
            for($i=0;$i<3;$i++){
                $buffer3=fgetc($myfile);
                if($buffer3!="\n")
                    $buffer2=$buffer2.$buffer3;
                else
                    $i=$i-1;
            }
            
            fwrite($newfile, $buffer2."\n");
            $buffer=$buffer.",".fgets($file);
            $buffer=str_replace("\n","",$buffer);
            fgets($myfile);
            fgets($myfile);

        
        fwrite($newfile, $buffer.",");
        }
    }
    fclose($myfile);
    fclose($newfile);
    fclose($file);
?>