<?php


$waiting=shell_exec("ps aux|grep ppero|wc -l");
$waittime=60;

while ($waiting>2){
echo($waittime);
sleep($waittime);
$waittime=$waittime*2;
$waiting=shell_exec("ps aux|grep ppero|wc -l");

if($waittime>172800)
{ exit;}

}

$Useq= $_POST["Sequ"].PHP_EOL;
$Uversion=$_POST["Version"];

$Utr=$_POST["Tr"];
$Utime=date('d-m-Y  H:i:s').PHP_EOL;

$logfilename = 'userslog.txt';
$inputfilename = 'candidates.fasta';

$outputfilename = 'newresult.txt';


if (is_writable($logfilename) ) {

    if (!$logfile= fopen($logfilename, 'a')) {
        echo "file to open $logfilename";
        exit;
    }

     if (!$inputfile= fopen($inputfilename, 'w+')) {
            echo "file to open $logfilename";
            exit;
        }



    if (fwrite($logfile, $Utime) === FALSE) {
        echo "file to write $logfilename";
        exit;
    }

    if (fwrite($inputfile, $Useq) === FALSE) {
        echo "file to write $inputfilename";
        exit;
    }

    
    fwrite($logfile, $Useq);
//    fwrite($inputfile, $Useq);

    fclose($logfile);

    if($Uversion=="At"){
    $command='php pperoat.php';}
    if($Uversion=="Gv")
    {$command='php pperopt.php';
    }
    system($command);
    system('php pero/sum2.php');

    fclose($inputfile);

} else {
    echo " log files can not be written";
}
header("Location: present.php?new=$Utr");
?>




