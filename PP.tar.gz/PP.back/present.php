<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Welcome</title>
    <style>
        <!--
        a { text-decoration: none}
        a:hover { color: #FFFFFF}
        -->
        body{text-align: center; margin-top:0px;background: #CCCCCC}
        .style1{text-align: left;margin:0 auto;width: 977px;height: 147px;background: rgb(42,45,48)}
        .text2{color:rgb(224,228,229);font-family:Arial, Helvetica,serif;position: relative; left: 37px }
        .order{background: rgb(42,45,48);width: 977px;height: 38px;text-align: left;margin:0 auto}
        .suborder{text-align:center;position:relative;float: left; left: 5px; width: 140px;height: 32px;top: 7px }
        .text1{font-size: 20px;font-family:Helvetica,serif;color: #CCCCCC}
        .line1{background: #CCCCCC;width: 977px;height: 7px;margin:0 auto}
        .line2{background: #CCCCCC;width: 977px;height: 27px;margin:0 auto}
        .end{text-align:center;margin:0 auto;width: 977px;height: 77px;background: rgb(42,45,48)}
        .text3{color: #CCCCCC;font-size: 11px;left: 12px;}
        .main{text-align: left;margin:0 auto;width: 977px;}
        .text8{color: rgb(91,91,91);font-size: 19px;left: 12px;font-family: Arial, Helvetica, serif}
        .subselect{text-align:left;position:relative;float: left; left: 5px; width: 240px;height: 30px; }

    </style>
</head>
<body>
<div id="header" class="style1">

    <div style="position: relative;top:38px">
        <a href="index.html" class="text2" style="font-size: 45px;text-shadow: 9px 7px 2px rgba(224,228,229,0.15)">
            PPero
        </a>
    </div>

    <div style="position: relative; top: 45px">
        <a href="index.html" class="text2" style="font-size: 22px;text-shadow: 3px 3px 0px rgba(224,228,229,0.2)">
            an accuracy computational model for PTS1 type protein predicting
        </a>
    </div>

</div>
<div class="line1"></div>

<div class="order">
    <div class="suborder">
        <a href="index.html" class="text1">Home </a>
    </div>
    <div class="suborder">
        <a href="help.html" class="text1">Help </a>
    </div>
    <div class="suborder">
        <a href="contact.html" class="text1">Contact us </a>
    </div>

</div>

<div class="line2">

</div>

<div class="main">
    <?php
$Tr= $_GET['new'];
$postfilename="newresults.txt";
$postfile = fopen("$postfilename", "r") or die("Unable to open file!");


if(filesize($postfilename)==0){
    echo '
    <p class="text8">NULL. Please check the input data or contact us </p>';

    }
    else{

     echo '
        <div style="width: 977px;height: 30px;text-align: left;margin:0 auto">
            <div class="subselect" style="left: 40px">
                <p class="text8">Name
                </p>
            </div>
            <div class="subselect" style="left: 40px">
                <p class="text8">Score
                </p>
            </div>
            <div class="subselect" style="left: 40px">
                <p class="text8">Targeting </p>
            </div>
        </div>
        ';

    while(!feof($postfile)) {
    $buffer=fgets($postfile);
    $buffer2=explode(",",$buffer);

    if(($buffer2[1]-0.2>=$Tr)&&($buffer2[1]!='')){

    echo '
    <div style="width: 977px;height: 30px;text-align: left;margin:0 auto">
        <div class="subselect" style="left: 40px">
            <p class="text8">';
                echo "$buffer2[0]";
                echo '
            </p>
        </div>
        <div class="subselect" style="left: 40px">
            <p class="text8">';
                echo "$buffer2[1]";
                echo '
            </p>
        </div>
        <div class="subselect" style="left: 40px">
            <p class="text8">Yes </p>
        </div>
    </div>
    ';
    }

    if(($buffer2[1]<=$Tr) && ($buffer2[1]!='')){
    echo '

    <div style="width: 977px;height: 30px;text-align: left;margin:0 auto">
        <div class="subselect" style="left: 40px">
            <p class="text8">';
                echo "$buffer2[0]";
                echo '
            </p>
        </div>
        <div class="subselect" style="left: 40px">
            <p class="text8">';
                echo "$buffer2[1]";
                echo '
            </p>
        </div>
        <div class="subselect" style="left: 40px">
            <p class="text8">No </p>
        </div>
    </div>
    ';
    }

    else if(($buffer2[1]>$Tr)&&($buffer2[1]<$Tr+0.2)&&($buffer2[1]!='')){ echo '

    <div style="width: 977px;height: 30px;text-align: left;margin:0 auto">
        <div class="subselect" style="left: 40px">
            <p class="text8">';
                echo "$buffer2[0]";
                echo '
            </p>
        </div>
        <div class="subselect" style="left: 40px">
            <p class="text8">';
                echo "$buffer2[1]";
                echo '
            </p>
        </div>
        <div class="subselect" style="left: 40px">
            <p class="text8">Perhaps yes </p>
        </div>
    </div>
    ';
    }
    }
    }
    fclose($postfile);
    unlink($postfilename);
    ?>


</div>
<div class="line2">

</div>
<div class="end ">
    <p class="text3">
        <br>
        ©2015 All Rights Reserved <br>
        Plant Metabolic Engineering and Systems Biology Research Laboratory<br>
        School of Life Sciences, The Chinese University of Hong Kong<br>
        Tel:(852) 3943 1258 Email:
        <a href="mailto:wangjuecuhk@yahoo.com" class="text3">wangjuecuhk@yahoo.com</a>
    </p>

</div>

</body>
</html>
