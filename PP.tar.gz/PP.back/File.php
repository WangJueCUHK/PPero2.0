<?php
    $myfile = fopen("candidates.potato.fasta", "r") or die("Unable to open file!");
    $newfile = fopen("candidates.fasta", "x") or die("Unable to open file!");
    $i=0;
    do {
        $buffer=fgets($myfile);
        if ($buffer[0]!='>'){
            fwrite($newfile, $buffer);
        }
        else{
            $buffer=substr($buffer,0,10);
            fwrite($newfile, $buffer);
            fwrite($newfile, "\n");
            $i+=1;

        }
    }while(!feof($myfile));
    fclose($myfile);
    fclose($newfile);
?>
    