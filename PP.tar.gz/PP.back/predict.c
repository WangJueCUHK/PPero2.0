//
//  predict.c
//  
//
//  Created by Wang Jue on 9/6/15.
//
//

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#define TDATA 30 // threshold number
#define MLEN 3000 // maxnium number of amino acid for each protein
#define MNUM 100000 // maxnium number of candidates

double matrix[40][TDATA];
char namedata[MNUM][15];

char seqdata[MNUM][TDATA];
double ppdata[MNUM][2*TDATA];
int n_data=0;


void readfile(char * filename)
{
    char (*predata)[MLEN]= malloc(sizeof(char)*MNUM*MLEN);
    int i=0;
    int j=0;
    int k,l,m;
    int c;
    FILE * fp;
    fp=fopen(filename,"r");
    if(fp==NULL)
        printf("error!");
    while ((c = fgetc(fp)) != EOF)
    {
        if(c=='>')
        {   fgets(namedata[i],15,fp);
            j=0;
            while(((c = fgetc(fp)) != '>')&&(c!=EOF))
            {   if(c!='\n')
            {   predata[i][j]=c;
                j++;
            }
                
            }
            i++;
            
        }
        if(c==EOF)
            break;
        else
            fseek(fp,-1,SEEK_CUR);
    }
    n_data=i;
    fclose(fp);
    for(j=0;j<i;j++)
    {
        k=strlen(predata[j])-1;
        for(l=0;l<TDATA;l++)
        {
            seqdata[j][l]=predata[j][k-l];
        }
        
    }
    free(predata);

}


void readmatrix(){
    int i,j;
    FILE * fp;
    fp=fopen("matrix.txt","r");
    for(i=0;i<40;i++){
        for(j=0;j<TDATA;j++){
            fscanf(fp,"%lf ",&matrix[i][j]);
        }
    }
    
    
    
}

void compute_matrix(){

    int i,j;

    for (i=0;i<n_data;i++){
        for (j=0;j<TDATA;j++){
            switch(seqdata[i][j]){
                case 'A':ppdata[i][j]=matrix[0][j];break;
                case 'R':ppdata[i][j]=matrix[1][j];break;
                case 'N':ppdata[i][j]=matrix[2][j];break;
                case 'D':ppdata[i][j]=matrix[3][j];break;
                case 'C':ppdata[i][j]=matrix[4][j];break;
                case 'E':ppdata[i][j]=matrix[5][j];break;
                case 'Q':ppdata[i][j]=matrix[6][j];break;
                case 'G':ppdata[i][j]=matrix[7][j];break;
                case 'H':ppdata[i][j]=matrix[8][j];break;
                case 'I':ppdata[i][j]=matrix[9][j];break;
                case 'L':ppdata[i][j]=matrix[10][j];break;
                case 'K':ppdata[i][j]=matrix[11][j];break;
                case 'M':ppdata[i][j]=matrix[12][j];break;
                case 'F':ppdata[i][j]=matrix[13][j];break;
                case 'P':ppdata[i][j]=matrix[14][j];break;
                case 'S':ppdata[i][j]=matrix[15][j];break;
                case 'T':ppdata[i][j]=matrix[16][j];break;
                case 'W':ppdata[i][j]=matrix[17][j];break;
                case 'Y':ppdata[i][j]=matrix[18][j];break;
                case 'V':ppdata[i][j]=matrix[19][j];break;
            }
        
        }
        for (j=TDATA;j<2*TDATA;j++){
            switch(seqdata[i][j]){
                case 'A':ppdata[i][j]=matrix[20][j-TDATA];break;
                case 'R':ppdata[i][j]=matrix[21][j-TDATA];break;
                case 'N':ppdata[i][j]=matrix[22][j-TDATA];break;
                case 'D':ppdata[i][j]=matrix[23][j-TDATA];break;
                case 'C':ppdata[i][j]=matrix[24][j-TDATA];break;
                case 'E':ppdata[i][j]=matrix[25][j-TDATA];break;
                case 'Q':ppdata[i][j]=matrix[26][j-TDATA];break;
                case 'G':ppdata[i][j]=matrix[27][j-TDATA];break;
                case 'H':ppdata[i][j]=matrix[28][j-TDATA];break;
                case 'I':ppdata[i][j]=matrix[29][j-TDATA];break;
                case 'L':ppdata[i][j]=matrix[30][j-TDATA];break;
                case 'K':ppdata[i][j]=matrix[31][j-TDATA];break;
                case 'M':ppdata[i][j]=matrix[32][j-TDATA];break;
                case 'F':ppdata[i][j]=matrix[33][j-TDATA];break;
                case 'P':ppdata[i][j]=matrix[34][j-TDATA];break;
                case 'S':ppdata[i][j]=matrix[35][j-TDATA];break;
                case 'T':ppdata[i][j]=matrix[36][j-TDATA];break;
                case 'W':ppdata[i][j]=matrix[37][j-TDATA];break;
                case 'Y':ppdata[i][j]=matrix[38][j-TDATA];break;
                case 'V':ppdata[i][j]=matrix[39][j-TDATA];break;
            }
            
            
            
        }

        
    }
    
}

void writepp(){
    int i,j;
    FILE * fp;
    fp=fopen("predict.txt","w");
    for(i=0;i<n_data;i++){
        
        fprintf(fp,"1 ");
        for(j=0;j<2*TDATA;j++){
            
            fprintf(fp,"%d:%lf ",j+1,ppdata[i][j]);
        }
        fprintf(fp,"\n");
    }
    
    
    
}

int main()
{
    char fname[]="candidates.fasta";
    readfile(fname);
    readmatrix();
    compute_matrix();
    remove("predict.txt");
    writepp();
    return 0;
    
    
}

