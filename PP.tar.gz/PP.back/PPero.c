//
//  PPero.c
//  
//
//  Created by Wang Jue on 24/5/15.
//
//

//
//  PPero.h
//
//
//  Created by Wang Jue on 24/5/15.
//
//



#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#define TDATA 30 // threshold number
#define MLEN 3000 // maxnium number of amino acid for each protein
char namedata_pos[300][1000];
char namedata_neg[1300][1000];
char postdata_pos[300][TDATA];
char postdata_neg[1300][TDATA];
double matrix_pos[300][2*TDATA];
double matrix_neg[1300][2*TDATA];
int n_data_pos=0;
int n_data_neg=0;
double pre_matrix_pos[20][TDATA];
double pre_matrix_neg[20][TDATA];


void readposfile(char * filename)
{   char predata_pos[1300][MLEN];
    int i=0;
    int j=0;
    int k,l,m;
    int c;
    FILE * fp;
    fp=fopen(filename,"r");
    if(fp==NULL)
        printf("error!");
    while ((c = fgetc(fp)) != EOF)
    {
        if(c=='>')
        {   fgets(namedata_pos[i],1000,fp);
            j=0;
            while(((c = fgetc(fp)) != '>')&&(c!=EOF))
            {   if(c!='\n')
                {   predata_pos[i][j]=c;
                    j++;
                }
        
            }
            i++;

        }
        if(c==EOF)
            break;
        else
            fseek(fp,-1,SEEK_CUR);
    }
    n_data_pos=i;
    fclose(fp);
    for(j=0;j<i;j++)
    {
        k=strlen(predata_pos[j])-1;
        for(l=0;l<TDATA;l++)
        {
            postdata_pos[j][l]=predata_pos[j][k-l];
        }
        
    }
}

void readnegfile(char * filename)
{   char predata_neg[1300][MLEN];
    int i=0;
    int j=0;
    int k,l,m;
    int c;
    FILE * fp;
    fp=fopen(filename,"r");
    if(fp==NULL)
        printf("error!");
    while ((c = fgetc(fp)) != EOF)
    {
        if(c=='>')
        {   fgets(namedata_neg[i],1000,fp);
            j=0;
            while(((c = fgetc(fp)) != '>')&&(c!=EOF))
            {   if(c!='\n')
            {   predata_neg[i][j]=c;
                j++;
            }
                
            }
            i++;
            
        }
        if(c==EOF)
            break;
        else
            fseek(fp,-1,SEEK_CUR);
    }
    n_data_neg=i;

    fclose(fp);
    for(j=0;j<i;j++)
    {
        k=strlen(predata_neg[j])-1;
        for(l=0;l<TDATA;l++)
        {
            postdata_neg[j][l]=predata_neg[j][k-l];
printf("%c",postdata_neg[j][l]);       
 }
        printf("\n");
    }
}

void getmatrix_pos()
{   int i,j,k;

    FILE * fp;
    fp=fopen("matrix.txt","a");
    if(fp==NULL)
        printf("error!");
    for (j=0;j<TDATA;j++)
    {   double tem[20]={0};
        for(i=0;i<n_data_pos;i++)
        {

            switch(postdata_pos[i][j]){
                case 'A':tem[0]++;break;
                case 'R':tem[1]++;break;
                    case 'N':tem[2]++;break;
                    case 'D':tem[3]++;break;
                    case 'C':tem[4]++;break;
                    case 'E':tem[5]++;break;
                    case 'Q':tem[6]++;break;
                    case 'G':tem[7]++;break;
                    case 'H':tem[8]++;break;
                    case 'I':tem[9]++;break;
                    case 'L':tem[10]++;break;
                    case 'K':tem[11]++;break;
                    case 'M':tem[12]++;break;
                    case 'F':tem[13]++;break;
                    case 'P':tem[14]++;break;
                    case 'S':tem[15]++;break;
                    case 'T':tem[16]++;break;
                    case 'W':tem[17]++;break;
                    case 'Y':tem[18]++;break;
                    case 'V':tem[19]++;break;
            }

        }
        for (i=0;i<20;i++){
            pre_matrix_pos[i][j]=tem[i]/n_data_pos;
        }
    }
    
    for (i=0;i<20;i++){
        for (j=0;j<TDATA;j++){
            fprintf(fp,"%lf ",pre_matrix_pos[i][j]);
        }
         fprintf(fp,"\n");
    }
    fclose(fp);
}


void getmatrix_neg()
{   int i,j,k;
    double matrix[20][TDATA];
    FILE * fp;
    fp=fopen("matrix.txt","a");
    if(fp==NULL)
        printf("error!");
    for (j=0;j<TDATA;j++)
    {   double tem[20]={0};
        for(i=0;i<n_data_neg;i++)
        {

            switch(postdata_neg[i][j]){
                case 'A':tem[0]++;break;
                case 'R':tem[1]++;break;
                case 'N':tem[2]++;break;
                case 'D':tem[3]++;break;
                case 'C':tem[4]++;break;
                case 'E':tem[5]++;break;
                case 'Q':tem[6]++;break;
                case 'G':tem[7]++;break;
                case 'H':tem[8]++;break;
                case 'I':tem[9]++;break;
                case 'L':tem[10]++;break;
                case 'K':tem[11]++;break;
                case 'M':tem[12]++;break;
                case 'F':tem[13]++;break;
                case 'P':tem[14]++;break;
                case 'S':tem[15]++;break;
                case 'T':tem[16]++;break;
                case 'W':tem[17]++;break;
                case 'Y':tem[18]++;break;
                case 'V':tem[19]++;break;
            }
            
        }
        for (i=0;i<20;i++){
            pre_matrix_neg[i][j]=tem[i]/n_data_neg;

        }
    }
    for (i=0;i<20;i++){
        for (j=0;j<TDATA;j++){
            fprintf(fp,"%lf ",pre_matrix_neg[i][j]);
            
        }
        fprintf(fp,"\n");
    }
    fclose(fp);
    
}

void write_matrix(){
    int i,j;
    FILE * fp;
    fp=fopen("train.txt","a");
    for (i=0;i<n_data_pos;i++){
        for (j=0;j<TDATA;j++){
            switch(postdata_pos[i][j]){
                case 'A':matrix_pos[i][j]=pre_matrix_pos[0][j];break;
                case 'R':matrix_pos[i][j]=pre_matrix_pos[1][j];break;
                case 'N':matrix_pos[i][j]=pre_matrix_pos[2][j];break;
                case 'D':matrix_pos[i][j]=pre_matrix_pos[3][j];break;
                case 'C':matrix_pos[i][j]=pre_matrix_pos[4][j];break;
                case 'E':matrix_pos[i][j]=pre_matrix_pos[5][j];break;
                case 'Q':matrix_pos[i][j]=pre_matrix_pos[6][j];break;
                case 'G':matrix_pos[i][j]=pre_matrix_pos[7][j];break;
                case 'H':matrix_pos[i][j]=pre_matrix_pos[8][j];break;
                case 'I':matrix_pos[i][j]=pre_matrix_pos[9][j];break;
                case 'L':matrix_pos[i][j]=pre_matrix_pos[10][j];break;
                case 'K':matrix_pos[i][j]=pre_matrix_pos[11][j];break;
                case 'M':matrix_pos[i][j]=pre_matrix_pos[12][j];break;
                case 'F':matrix_pos[i][j]=pre_matrix_pos[13][j];break;
                case 'P':matrix_pos[i][j]=pre_matrix_pos[14][j];break;
                case 'S':matrix_pos[i][j]=pre_matrix_pos[15][j];break;
                case 'T':matrix_pos[i][j]=pre_matrix_pos[16][j];break;
                case 'W':matrix_pos[i][j]=pre_matrix_pos[17][j];break;
                case 'Y':matrix_pos[i][j]=pre_matrix_pos[18][j];break;
                case 'V':matrix_pos[i][j]=pre_matrix_pos[19][j];break;
            }
        }
        for (j=TDATA;j<2*TDATA;j++){
            switch(postdata_pos[i][j]){
                case 'A':matrix_pos[i][j]=pre_matrix_neg[0][j-TDATA];break;
                case 'R':matrix_pos[i][j]=pre_matrix_neg[1][j-TDATA];break;
                case 'N':matrix_pos[i][j]=pre_matrix_neg[2][j-TDATA];break;
                case 'D':matrix_pos[i][j]=pre_matrix_neg[3][j-TDATA];break;
                case 'C':matrix_pos[i][j]=pre_matrix_neg[4][j-TDATA];break;
                case 'E':matrix_pos[i][j]=pre_matrix_neg[5][j-TDATA];break;
                case 'Q':matrix_pos[i][j]=pre_matrix_neg[6][j-TDATA];break;
                case 'G':matrix_pos[i][j]=pre_matrix_neg[7][j-TDATA];break;
                case 'H':matrix_pos[i][j]=pre_matrix_neg[8][j-TDATA];break;
                case 'I':matrix_pos[i][j]=pre_matrix_neg[9][j-TDATA];break;
                case 'L':matrix_pos[i][j]=pre_matrix_neg[10][j-TDATA];break;
                case 'K':matrix_pos[i][j]=pre_matrix_neg[11][j-TDATA];break;
                case 'M':matrix_pos[i][j]=pre_matrix_neg[12][j-TDATA];break;
                case 'F':matrix_pos[i][j]=pre_matrix_neg[13][j-TDATA];break;
                case 'P':matrix_pos[i][j]=pre_matrix_neg[14][j-TDATA];break;
                case 'S':matrix_pos[i][j]=pre_matrix_neg[15][j-TDATA];break;
                case 'T':matrix_pos[i][j]=pre_matrix_neg[16][j-TDATA];break;
                case 'W':matrix_pos[i][j]=pre_matrix_neg[17][j-TDATA];break;
                case 'Y':matrix_pos[i][j]=pre_matrix_neg[18][j-TDATA];break;
                case 'V':matrix_pos[i][j]=pre_matrix_neg[19][j-TDATA];break;
            }
            
        }
        
    }
    for (i=0;i<n_data_neg;i++){
        for (j=0;j<TDATA;j++){
            switch(postdata_neg[i][j]){
                case 'A':matrix_neg[i][j]=pre_matrix_neg[0][j];break;
                case 'R':matrix_neg[i][j]=pre_matrix_neg[1][j];break;
                case 'N':matrix_neg[i][j]=pre_matrix_neg[2][j];break;
                case 'D':matrix_neg[i][j]=pre_matrix_neg[3][j];break;
                case 'C':matrix_neg[i][j]=pre_matrix_neg[4][j];break;
                case 'E':matrix_neg[i][j]=pre_matrix_neg[5][j];break;
                case 'Q':matrix_neg[i][j]=pre_matrix_neg[6][j];break;
                case 'G':matrix_neg[i][j]=pre_matrix_neg[7][j];break;
                case 'H':matrix_neg[i][j]=pre_matrix_neg[8][j];break;
                case 'I':matrix_neg[i][j]=pre_matrix_neg[9][j];break;
                case 'L':matrix_neg[i][j]=pre_matrix_neg[10][j];break;
                case 'K':matrix_neg[i][j]=pre_matrix_neg[11][j];break;
                case 'M':matrix_neg[i][j]=pre_matrix_neg[12][j];break;
                case 'F':matrix_neg[i][j]=pre_matrix_neg[13][j];break;
                case 'P':matrix_neg[i][j]=pre_matrix_neg[14][j];break;
                case 'S':matrix_neg[i][j]=pre_matrix_neg[15][j];break;
                case 'T':matrix_neg[i][j]=pre_matrix_neg[16][j];break;
                case 'W':matrix_neg[i][j]=pre_matrix_neg[17][j];break;
                case 'Y':matrix_neg[i][j]=pre_matrix_neg[18][j];break;
                case 'V':matrix_neg[i][j]=pre_matrix_neg[19][j];break;
            }
        }
        for (j=TDATA;j<2*TDATA;j++){
            switch(postdata_pos[i][j]){
                case 'A':matrix_neg[i][j]=pre_matrix_pos[0][j-TDATA];break;
                case 'R':matrix_neg[i][j]=pre_matrix_pos[1][j-TDATA];break;
                case 'N':matrix_neg[i][j]=pre_matrix_pos[2][j-TDATA];break;
                case 'D':matrix_neg[i][j]=pre_matrix_pos[3][j-TDATA];break;
                case 'C':matrix_neg[i][j]=pre_matrix_pos[4][j-TDATA];break;
                case 'E':matrix_neg[i][j]=pre_matrix_pos[5][j-TDATA];break;
                case 'Q':matrix_neg[i][j]=pre_matrix_pos[6][j-TDATA];break;
                case 'G':matrix_neg[i][j]=pre_matrix_pos[7][j-TDATA];break;
                case 'H':matrix_neg[i][j]=pre_matrix_pos[8][j-TDATA];break;
                case 'I':matrix_neg[i][j]=pre_matrix_pos[9][j-TDATA];break;
                case 'L':matrix_neg[i][j]=pre_matrix_pos[10][j-TDATA];break;
                case 'K':matrix_neg[i][j]=pre_matrix_pos[11][j-TDATA];break;
                case 'M':matrix_neg[i][j]=pre_matrix_pos[12][j-TDATA];break;
                case 'F':matrix_neg[i][j]=pre_matrix_pos[13][j-TDATA];break;
                case 'P':matrix_neg[i][j]=pre_matrix_pos[14][j-TDATA];break;
                case 'S':matrix_neg[i][j]=pre_matrix_pos[15][j-TDATA];break;
                case 'T':matrix_neg[i][j]=pre_matrix_pos[16][j-TDATA];break;
                case 'W':matrix_neg[i][j]=pre_matrix_pos[17][j-TDATA];break;
                case 'Y':matrix_neg[i][j]=pre_matrix_pos[18][j-TDATA];break;
                case 'V':matrix_neg[i][j]=pre_matrix_pos[19][j-TDATA];break;
            }
            
        }
        
    }
    for (i=0;i<n_data_pos;i++){
        fprintf(fp,"1 ");
        for (j=0;j<2*TDATA;j++){
            fprintf(fp,"%d:%lf ",j+1,matrix_pos[i][j]);
        }
        fprintf(fp,"\n");
    }
    for (i=0;i<n_data_neg;i++){
        fprintf(fp,"-1 ");
        for (j=0;j<2*TDATA;j++){
            fprintf(fp,"%d:%lf ",j+1,matrix_neg[i][j]);
        }
        fprintf(fp,"\n");
    }
    fclose(fp);


}

int main()
{  
    char fnamepos[]="pos_data.fasta";
    char fnameneg[]="neg_data.fasta";
//    readposfile(fnamepos);
    readnegfile(fnameneg);
    remove("matrix.txt");
    remove("train.txt");
    
    getmatrix_pos();
    getmatrix_neg();
    write_matrix();
    return 0;
  
    
}

